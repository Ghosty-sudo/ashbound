extends CharacterBody2D

@export var area_id: int = 1
@export var base_level: int = 1
@export var loot_id: String = "slime_gel"
@export var body_color: Color = Color(0.2,0.8,0.3,1.0)
@export var base_hp: int = 35
@export var base_damage: int = 5
@export var move_speed: float = 60.0

var level: int = 1
var rarity: int = 0
var hp: int = 1
var max_hp_value: int = 1
var damage: int = 1
var spawn_position: Vector2
var aggroed: bool = false
var attack_timer: float = 0.0
var stagger_timer: float = 0.0
var dead: bool = false

func _ready() -> void:
    spawn_position = global_position
    roll_spawn()

func is_enemy() -> bool:
    return true

func roll_spawn() -> void:
    level = base_level + randi_range(0,2)
    var roll := randf()

    if roll < 0.01:
        rarity = 4
    elif roll < 0.03:
        rarity = 3
    elif roll < 0.09:
        rarity = 2
    elif roll < 0.22:
        rarity = 1
    else:
        rarity = 0

    var multipliers: Array = [1.0,1.2,1.5,1.9,2.4]
    var mult: float = float(multipliers[rarity])

    max_hp_value = int(round((base_hp + level*8)*mult))
    damage = int(round((base_damage + level*1.4)*(1.0 + (mult-1.0)*0.6)))
    hp = max_hp_value
    aggroed = false
    dead = false

func _physics_process(delta: float) -> void:
    if get_tree().paused or dead:
        return

    if get_parent().current_area != area_id:
        visible = false
        aggroed = false
        return

    visible = true
    attack_timer = maxf(0.0,attack_timer-delta)
    stagger_timer = maxf(0.0,stagger_timer-delta)

    var player = get_parent().get_node_or_null("Player")
    if player == null:
        return

    var distance: float = global_position.distance_to(player.global_position)

    if not aggroed and distance <= 180.0:
        aggroed = true

    if not aggroed:
        queue_redraw()
        return

    if stagger_timer > 0.0:
        queue_redraw()
        return

    if distance > 34.0:
        global_position += global_position.direction_to(player.global_position)*move_speed*delta
    elif attack_timer <= 0.0:
        attack_timer = 0.9
        player.take_damage(damage,global_position.direction_to(player.global_position))

    queue_redraw()

func take_damage(amount: int, direction: Vector2, critical: bool = false) -> void:
    if dead:
        return

    aggroed = true
    hp = maxi(0,hp-amount)
    stagger_timer = 0.08
    global_position += direction.normalized()*8.0
    get_parent().spawn_damage_number(global_position,amount,critical)

    if hp <= 0:
        die()

func die() -> void:
    dead = true
    visible = false

    var player = get_parent().get_node_or_null("Player")
    if player != null:
        player.gain_xp(10+level*3)
        player.gold += 2+rarity*2

    if randf() < 0.60+rarity*0.06:
        get_parent().spawn_loot(global_position,loot_id,1+(1 if rarity>=2 else 0),area_id)

    await get_tree().create_timer(3.0).timeout
    global_position = spawn_position
    roll_spawn()
    visible = true

func rarity_color() -> Color:
    var colors: Array = [
        Color(0.8,0.8,0.8,1.0),
        Color(0.2,0.9,0.3,1.0),
        Color(0.25,0.55,1.0,1.0),
        Color(0.75,0.25,1.0,1.0),
        Color(1.0,0.65,0.1,1.0)
    ]
    return colors[rarity]

func _draw() -> void:
    var ratio: float = float(hp)/float(maxi(1,max_hp_value))
    draw_rect(Rect2(-18,-26,36,5),Color(0.08,0.08,0.08,1.0))
    draw_rect(Rect2(-18,-26,36*ratio,5),rarity_color())
    draw_string(ThemeDB.fallback_font,Vector2(-12,-31),"Lv.%d" % level,HORIZONTAL_ALIGNMENT_LEFT,32,12,rarity_color())
    draw_rect(Rect2(-12,-12,24,24),body_color)

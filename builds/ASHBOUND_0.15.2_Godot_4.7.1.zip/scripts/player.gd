extends CharacterBody2D

var hp: int = 105
var level: int = 1
var xp: int = 0
var xp_to_next: int = 30
var gold: int = 0
var attribute_points: int = 0

var strength: int = 1
var charisma: int = 1
var intelligence: int = 1
var constitution: int = 1
var defense: int = 0

var facing: Vector2 = Vector2.RIGHT
var attack_timer: float = 0.0
var attack_draw_timer: float = 0.0
var weapon_index: int = 0

var inventory: Dictionary = {
    "slime_gel": 0,
    "red_herb": 0,
    "wolf_fang": 0,
    "goblin_hide": 0,
    "iron_shard": 0,
    "health_potion": 1
}

var weapons: Array = [
    {"name":"Sword","damage":14,"aps":1.30,"range":62.0,"arc":0.15,"cleave":[1.0,0.72,0.52,0.38]},
    {"name":"Greatsword","damage":24,"aps":0.72,"range":72.0,"arc":-0.15,"cleave":[1.0,0.82,0.68,0.55,0.45]},
    {"name":"Dagger","damage":8,"aps":2.10,"range":48.0,"arc":0.45,"cleave":[1.0,0.55,0.30]}
]

func _ready() -> void:
    hp = max_hp()
    queue_redraw()

func max_hp() -> int:
    return 100 + constitution * 5

func max_mana() -> int:
    return 45 + intelligence * 5

func crit_damage() -> float:
    return 1.50 + charisma * 0.03

func stat_cost(value: int) -> int:
    return 1 + int((value - 1) / 5)

func current_weapon() -> Dictionary:
    return weapons[weapon_index]

func current_damage() -> int:
    var base_damage: int = int(current_weapon()["damage"]) + (level - 1) * 2
    return int(round(base_damage * (1.0 + strength * 0.02)))

func _physics_process(delta: float) -> void:
    if get_tree().paused:
        velocity = Vector2.ZERO
        return

    attack_timer = maxf(0.0, attack_timer - delta)
    attack_draw_timer = maxf(0.0, attack_draw_timer - delta)

    var direction := Input.get_vector("move_left","move_right","move_up","move_down")
    if direction.length() > 0.0:
        facing = direction.normalized()

    velocity = direction * 180.0
    move_and_slide()

    position.x = clampf(position.x,16.0,944.0)
    position.y = clampf(position.y,70.0,524.0)

    if Input.is_action_just_pressed("attack"):
        attack()

    if Input.is_action_just_pressed("cycle_weapon"):
        weapon_index = (weapon_index + 1) % weapons.size()

    if Input.is_action_just_pressed("use_potion"):
        use_health_potion()

    queue_redraw()

func attack() -> void:
    if attack_timer > 0.0:
        return

    attack_timer = 1.0 / float(current_weapon()["aps"])
    attack_draw_timer = 0.12

    var hits: Array = []

    for node in get_parent().get_children():
        if node.has_method("is_enemy") and node.is_enemy() and node.visible:
            var offset: Vector2 = node.global_position - global_position
            if offset.length() <= 0.001:
                continue
            if offset.length() > float(current_weapon()["range"]):
                continue
            if facing.dot(offset.normalized()) < float(current_weapon()["arc"]):
                continue
            hits.append({"node":node,"distance":offset.length()})

    hits.sort_custom(func(a,b): return a["distance"] < b["distance"])
    var cleave: Array = current_weapon()["cleave"]

    for i in range(hits.size()):
        var factor: float = float(cleave[mini(i,cleave.size()-1)])
        var critical: bool = randf() < 0.05
        var amount: int = maxi(1,int(round(current_damage()*factor)))
        if critical:
            amount = int(round(amount*crit_damage()))
        hits[i]["node"].take_damage(amount,facing,critical)

func take_damage(amount: int, _direction: Vector2) -> void:
    hp = maxi(0,hp-maxi(1,amount-defense))
    if hp <= 0:
        hp = max_hp()
        gold = int(floor(gold*0.90))
        get_parent().return_to_town()

func gain_xp(amount: int) -> void:
    xp += amount
    while xp >= xp_to_next:
        xp -= xp_to_next
        level += 1

        if level <= 5:
            attribute_points += 3
        elif level <= 10:
            attribute_points += 4
        else:
            attribute_points += 5

        xp_to_next = int(round(xp_to_next*1.35))
        hp = max_hp()

func spend_attribute(stat_name: String) -> bool:
    var current_value := 1

    match stat_name:
        "strength":
            current_value = strength
        "charisma":
            current_value = charisma
        "intelligence":
            current_value = intelligence
        "constitution":
            current_value = constitution
        _:
            return false

    var cost := stat_cost(current_value)
    if attribute_points < cost:
        return false

    attribute_points -= cost

    match stat_name:
        "strength":
            strength += 1
        "charisma":
            charisma += 1
        "intelligence":
            intelligence += 1
        "constitution":
            constitution += 1
            hp = mini(max_hp(),hp+5)

    return true

func add_item(item_id: String, amount: int = 1) -> void:
    inventory[item_id] = inventory.get(item_id,0) + amount

func use_health_potion() -> void:
    if inventory.get("health_potion",0) > 0 and hp < max_hp():
        inventory["health_potion"] -= 1
        hp = mini(max_hp(),hp+35)

func _draw() -> void:
    if attack_draw_timer > 0.0:
        var attack_range: float = float(current_weapon()["range"])
        var half_arc: float = acos(clampf(float(current_weapon()["arc"]),-1.0,1.0))
        var center: float = facing.angle()
        draw_arc(Vector2.ZERO,attack_range,center-half_arc,center+half_arc,28,Color(1,1,1,0.9),4.0)

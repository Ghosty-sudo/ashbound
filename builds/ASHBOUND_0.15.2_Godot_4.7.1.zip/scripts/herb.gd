extends Node2D

@export var area_id: int = 1
@export var respawn_seconds: float = 15.0

var available: bool = true

func _process(_delta: float) -> void:
    visible = get_parent().current_area == area_id and available
    queue_redraw()

func can_interact(player: Node) -> bool:
    return available and visible and global_position.distance_to(player.global_position) < 48.0

func harvest(player: Node) -> void:
    if not can_interact(player):
        return

    available = false
    player.add_item("red_herb",1)
    get_parent().announce("Harvested Red Herb.")

    await get_tree().create_timer(respawn_seconds).timeout
    available = true

func _draw() -> void:
    if not available:
        return

    draw_line(Vector2(0,8),Vector2(0,-8),Color(0.15,0.8,0.2,1.0),4.0)
    draw_circle(Vector2(-5,-4),5.0,Color(0.2,0.75,0.25,1.0))
    draw_circle(Vector2(5,-2),5.0,Color(0.2,0.85,0.3,1.0))
    draw_circle(Vector2(0,-8),4.0,Color(0.9,0.18,0.25,1.0))

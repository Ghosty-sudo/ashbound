extends Node2D

var item_id: String = "slime_gel"
var amount: int = 1
var area_id: int = 1

func _process(_delta: float) -> void:
    if get_tree().paused:
        return

    visible = get_parent().current_area == area_id
    if not visible:
        return

    var player = get_parent().get_node_or_null("Player")
    if player != null and global_position.distance_to(player.global_position) < 22.0:
        player.add_item(item_id,amount)
        queue_free()

func _draw() -> void:
    draw_circle(Vector2.ZERO,7.0,Color(1.0,0.8,0.2,1.0))

extends Node2D

@onready var player = $Player
@onready var menu_panel = $HUD/Menu
@onready var dev_panel = $HUD/Dev

var current_area: int = 0

var area_names: Array = [
    "Town",
    "Slime Fields",
    "Wolf Woods",
    "Goblin Territory",
    "Dungeon Entrance"
]

var tabs: Array = ["INVENTORY","EQUIPMENT","STATS","CRAFTING"]

var current_tab: int = 0
var selected_stat: int = 0

var stats_order: Array = [
    "strength",
    "charisma",
    "intelligence",
    "constitution"
]

var menu_open: bool = false
var dev_open: bool = false
var service_mode: String = ""

func _ready() -> void:
    randomize()
    process_mode = Node.PROCESS_MODE_ALWAYS
    $HUD.process_mode = Node.PROCESS_MODE_ALWAYS
    menu_panel.process_mode = Node.PROCESS_MODE_ALWAYS
    dev_panel.process_mode = Node.PROCESS_MODE_ALWAYS

    menu_panel.visible = false
    dev_panel.visible = false

    update_world_visuals()

func _process(_delta: float) -> void:
    $HUD/Top.text = "HP %d/%d | Lv %d | XP %d/%d | Gold %d | %s | DMG %d | Points %d" % [
        player.hp,
        player.max_hp(),
        player.level,
        player.xp,
        player.xp_to_next,
        player.gold,
        player.current_weapon()["name"],
        player.current_damage(),
        player.attribute_points
    ]

    $HUD/Area.text = area_names[current_area]

    if menu_open:
        $HUD/Menu/Header.text = tabs[current_tab]
        $HUD/Menu/Scroll/Text.text = tab_text()

    if not get_tree().paused:
        handle_area_transitions()
        update_prompt()

func handle_area_transitions() -> void:
    if current_area == 0:
        if player.position.y < 82.0:
            current_area = 1
            player.position = Vector2(480,500)
            update_world_visuals()
    else:
        if player.position.x > 930.0 and current_area < area_names.size()-1:
            current_area += 1
            player.position.x = 30.0
            update_world_visuals()
        elif player.position.x < 30.0 and current_area > 1:
            current_area -= 1
            player.position.x = 930.0
            update_world_visuals()
        elif current_area == 1 and player.position.y > 510.0:
            current_area = 0
            player.position = Vector2(480,105)
            update_world_visuals()

func update_world_visuals() -> void:
    $TownObjects.visible = current_area == 0

    var colors: Array = [
        Color(0.20,0.18,0.14,1.0),
        Color(0.10,0.22,0.12,1.0),
        Color(0.08,0.17,0.10,1.0),
        Color(0.20,0.16,0.08,1.0),
        Color(0.08,0.08,0.11,1.0)
    ]

    $Background.color = colors[current_area]

func update_prompt() -> void:
    $HUD/Prompt.text = ""

    if current_area == 0:
        if player.position.distance_to(Vector2(215,220)) < 85.0:
            $HUD/Prompt.text = "E - Interact with Blacksmith"
            return

        if player.position.distance_to(Vector2(745,220)) < 85.0:
            $HUD/Prompt.text = "E - Interact with Alchemist"
            return

    for node in get_children():
        if node.has_method("can_interact") and node.can_interact(player):
            $HUD/Prompt.text = "E - Harvest Red Herb"
            return

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("dev_menu"):
        toggle_dev()
        return

    if dev_open:
        handle_dev_input(event)
        return

    if menu_open:
        handle_menu_input(event)
        return

    if event.is_action_pressed("character_menu"):
        open_menu(0)
    elif event.is_action_pressed("craft_tab"):
        open_menu(3)
    elif event.is_action_pressed("gear_tab"):
        open_menu(1)
    elif event.is_action_pressed("interact"):
        interact_world()

func handle_menu_input(event: InputEvent) -> void:
    if event.is_action_pressed("menu_back") \
    or event.is_action_pressed("interact") \
    or event.is_action_pressed("character_menu"):
        close_menu()
        return

    if event.is_action_pressed("move_left"):
        current_tab = (current_tab - 1 + tabs.size()) % tabs.size()
        selected_stat = 0

    elif event.is_action_pressed("move_right"):
        current_tab = (current_tab + 1) % tabs.size()
        selected_stat = 0

    elif current_tab == 2 and event.is_action_pressed("move_up"):
        selected_stat = (selected_stat - 1 + stats_order.size()) % stats_order.size()

    elif current_tab == 2 and event.is_action_pressed("move_down"):
        selected_stat = (selected_stat + 1) % stats_order.size()

    elif current_tab == 2 and event.is_action_pressed("attack"):
        player.spend_attribute(stats_order[selected_stat])

    elif current_tab != 2 and event.is_action_pressed("move_down"):
        $HUD/Menu/Scroll.scroll_vertical += 35

    elif current_tab != 2 and event.is_action_pressed("move_up"):
        $HUD/Menu/Scroll.scroll_vertical -= 35

func open_menu(tab_index: int) -> void:
    current_tab = tab_index
    selected_stat = 0
    menu_open = true
    menu_panel.visible = true
    get_tree().paused = true

func close_menu() -> void:
    menu_open = false
    menu_panel.visible = false
    service_mode = ""
    get_tree().paused = false

func interact_world() -> void:
    if current_area == 0:
        if player.position.distance_to(Vector2(215,220)) < 85.0:
            service_mode = "blacksmith"
            open_menu(3)
            announce("Blacksmith crafting available.")
            return

        if player.position.distance_to(Vector2(745,220)) < 85.0:
            service_mode = "alchemist"
            open_menu(3)
            announce("Alchemist crafting available.")
            return

    for node in get_children():
        if node.has_method("can_interact") and node.can_interact(player):
            node.harvest(player)
            return

func craft_health_potion() -> bool:
    if player.inventory["slime_gel"] < 2 or player.inventory["red_herb"] < 1:
        return false

    player.inventory["slime_gel"] -= 2
    player.inventory["red_herb"] -= 1
    player.inventory["health_potion"] += 1
    return true

func craft_fang_edge() -> bool:
    if player.inventory["wolf_fang"] < 4 or player.inventory["iron_shard"] < 2:
        return false

    player.inventory["wolf_fang"] -= 4
    player.inventory["iron_shard"] -= 2

    for weapon in player.weapons:
        weapon["damage"] = int(weapon["damage"]) + 2

    return true

func craft_hide_guard() -> bool:
    if player.inventory["goblin_hide"] < 4:
        return false

    player.inventory["goblin_hide"] -= 4
    player.defense += 1
    return true

func toggle_dev() -> void:
    dev_open = not dev_open
    dev_panel.visible = dev_open
    menu_panel.visible = false
    menu_open = false
    get_tree().paused = dev_open

func handle_dev_input(event: InputEvent) -> void:
    if event.is_action_pressed("menu_back") or event.is_action_pressed("dev_menu"):
        toggle_dev()
        return

    if event is InputEventKey and event.pressed:
        match event.physical_keycode:
            KEY_1:
                player.gain_xp(player.xp_to_next)
            KEY_2:
                player.attribute_points += 10
            KEY_3:
                for key in player.inventory.keys():
                    player.inventory[key] += 20
            KEY_4:
                player.gold += 1000
            KEY_5:
                player.hp = player.max_hp()

func stat_marker(index: int) -> String:
    return "> " if selected_stat == index else "  "

func tab_text() -> String:
    if current_tab == 0:
        return "MATERIALS\n\nSlime Gel ........ %d\nRed Herb ......... %d\nWolf Fang ........ %d\nGoblin Hide ...... %d\nIron Shard ....... %d\n\nCONSUMABLES\n\nHealth Potion .... %d" % [
            player.inventory["slime_gel"],
            player.inventory["red_herb"],
            player.inventory["wolf_fang"],
            player.inventory["goblin_hide"],
            player.inventory["iron_shard"],
            player.inventory["health_potion"]
        ]

    if current_tab == 1:
        return "EQUIPMENT\n\nWeapon: %s\n\nHead: Empty\nChest: Empty\nHands: Empty\nLegs: Empty\nBoots: Empty\nRing: Empty\nNecklace: Empty\n\nDamage: %d\nDefense: %d\nCrit Damage: %.0f%%" % [
            player.current_weapon()["name"],
            player.current_damage(),
            player.defense,
            player.crit_damage()*100.0
        ]

    if current_tab == 2:
        return "ATTRIBUTES\nAvailable Points: %d\n\n%sStrength: %d\n  +%d%% Physical Damage\n  Cost: %d\n\n%sCharisma: %d\n  Crit Damage: %.0f%%\n  Cost: %d\n\n%sIntelligence: %d\n  Max Mana: %d\n  Cost: %d\n\n%sConstitution: %d\n  Max HP: %d\n  Cost: %d\n\nW/S selects.\nSPACE spends points." % [
            player.attribute_points,
            stat_marker(0),player.strength,player.strength*2,player.stat_cost(player.strength),
            stat_marker(1),player.charisma,player.crit_damage()*100.0,player.stat_cost(player.charisma),
            stat_marker(2),player.intelligence,player.max_mana(),player.stat_cost(player.intelligence),
            stat_marker(3),player.constitution,player.max_hp(),player.stat_cost(player.constitution)
        ]

    if service_mode == "alchemist":
        return "ALCHEMIST\n\nHealth Potion\nCost: 2 Slime Gel + 1 Red Herb\n\nPress SPACE to craft one potion.\n\nCurrent:\nSlime Gel %d\nRed Herb %d\nHealth Potions %d" % [
            player.inventory["slime_gel"],
            player.inventory["red_herb"],
            player.inventory["health_potion"]
        ]

    if service_mode == "blacksmith":
        return "BLACKSMITH\n\nFang Edge\n4 Wolf Fang + 2 Iron Shard\n+2 damage to prototype weapons\n\nHide Guard\n4 Goblin Hide\n+1 Defense\n\nSPACE crafts Fang Edge first if affordable,\notherwise Hide Guard." 

    return "CRAFTING REFERENCE\n\nHealth Potion\n2 Slime Gel + 1 Red Herb\nRequires: Alchemist\n\nFang Edge\n4 Wolf Fang + 2 Iron Shard\nRequires: Blacksmith\n\nHide Guard\n4 Goblin Hide\nRequires: Blacksmith"

func _input(event: InputEvent) -> void:
    if not menu_open:
        return

    if current_tab != 3:
        return

    if not event.is_action_pressed("attack"):
        return

    if service_mode == "alchemist":
        if craft_health_potion():
            announce("Crafted Health Potion.")
        else:
            announce("Not enough potion ingredients.")

    elif service_mode == "blacksmith":
        if craft_fang_edge():
            announce("Crafted Fang Edge upgrade.")
        elif craft_hide_guard():
            announce("Crafted Hide Guard.")
        else:
            announce("Not enough blacksmith materials.")

func spawn_loot(world_position: Vector2, item_id: String, amount: int, area_id: int) -> void:
    var loot = Node2D.new()
    loot.set_script(load("res://scripts/loot.gd"))
    add_child(loot)
    loot.global_position = world_position
    loot.item_id = item_id
    loot.amount = amount
    loot.area_id = area_id

func spawn_damage_number(world_position: Vector2, amount: int, critical: bool) -> void:
    var label := Label.new()
    label.text = "-%d%s" % [amount,"!" if critical else ""]
    label.position = world_position + Vector2(-10,-24)
    add_child(label)

    var tween := create_tween()
    tween.tween_property(label,"position",label.position+Vector2(0,-28),0.45)
    tween.parallel().tween_property(label,"modulate:a",0.0,0.45)
    tween.tween_callback(label.queue_free)

func announce(message: String) -> void:
    $HUD/Log.text = message

func return_to_town() -> void:
    current_area = 0
    player.position = Vector2(480,350)
    update_world_visuals()

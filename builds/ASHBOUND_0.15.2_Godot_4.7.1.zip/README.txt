Medieval Pixel RPG Prototype 0.15.2
Target Godot 4.7.1

FIXED:
- Stats reordered: STR / CHA / INT / CON
- SPACE spends attribute points in Stats tab
- E no longer spends points; it remains interact/close
- Red Herb harvest nodes restored to Slime Fields
- Blacksmith interaction added
- Alchemist interaction added
- Town prompts show when near their doors
- Blacksmith/Alchemist open context-sensitive crafting UI
- SPACE crafts while using a town service
- Combat, levels, rarities, multi-target cleave, local aggro retained

Blacksmith:
Fang Edge = 4 Wolf Fang + 2 Iron Shard
Hide Guard = 4 Goblin Hide

Alchemist:
Health Potion = 2 Slime Gel + 1 Red Herb

Stats:
W/S = choose stat
SPACE = spend points

Menu:
E / ESC / I = close

Town:
Blacksmith left
Alchemist right
North Gate leads to Slime Fields
